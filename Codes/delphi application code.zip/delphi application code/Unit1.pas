unit Unit1;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, dialogs, jpeg, DateUtils, Menus;

type
  TFORM1 = class(TForm)
    Edit1: TEdit;
    Label2: TLabel;
    Edit2: TEdit;
    Label1: TLabel;
    Panel1: TPanel;
    procedure Edit1KeyPress(Sender: TObject; var Key: Char);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Exit1Click(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FORM1: TFORM1;
  theuser:string;
  filepat:string;
  isanadmin: boolean=false;

implementation

uses Unit2;

{$R *.dfm}
procedure setAsMainForm(aForm:Tform);
VAR
  p:Pointer;
begin
  p:=@Application.MainForm;
  Pointer(p^):=aform;
END;
procedure TFORM1.Edit1KeyPress(Sender: TObject; var Key: Char);
type
TUser=Record
  name: string[30];                              //classs declare
  password: string[15];
  admin: boolean;
  end;
var
  userfile:file of Tuser;
  user:Tuser;
  found, ok:boolean;
begin
  if(ord(key)=13) then begin
    key:=#0;
    if(edit1.Text='') then begin panel1.Caption:='Enter name'; edit1.SetFocus; unit2.start:=3; exit; end;
    if(edit2.Text='') then begin panel1.Caption:='Enter user password'; edit2.SetFocus; unit2.start:=3; exit; end;
    if(fileexists(filepat+'\users.bin')=false) then begin
      panel1.Caption:='Unknown User name'; unit2.start:=3; edit1.SetFocus; exit;
    end;
    found:=false; ok:=false;
    assignfile(userfile, filepat+'\users.bin');
    reset(userfile);
    while not eof(userfile) do begin
      read(userfile, user);
      if(lowercase(user.name)=lowercase(edit1.Text)) then begin
        found:=true;
        if(user.password=edit2.Text) then begin
          ok:=true;
          theuser:=user.name;
          isanadmin:=user.admin;
        end else begin
          panel1.Caption:='Incorrect password for Above user name';
          edit2.SetFocus; unit2.start:=4; exit;
        end;
      end;
    end;
    closefile(userfile);
    if(found=true) and (ok=true) then begin
      form1.Hide;
      form2.Show;
    end;
  end;
end;

procedure TFORM1.FormCreate(Sender: TObject);
begin
  panel1.Caption:='';
  filepat:=getcurrentdir+'\data';
end;

procedure TFORM1.FormShow(Sender: TObject);
begin
  setAsMainForm(form1);
  edit1.Text:='';
  edit2.Text:='';
end;

procedure TFORM1.Exit1Click(Sender: TObject);
begin
  application.Terminate;
end;

procedure TFORM1.Label1Click(Sender: TObject);
begin
  form1.Hide;
  form2.Show;
end;

end.

