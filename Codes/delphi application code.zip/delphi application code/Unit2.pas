unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, jpeg, Menus, CPort, ComCtrls, Mask, dateutils,
  Grids;

type
  TForm2 = class(TForm)
    Panel2: TPanel;
    Panel5: TPanel;
    Timer1: TTimer;
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    Open1: TMenuItem;
    Logout1: TMenuItem;
    Exit1: TMenuItem;
    View1: TMenuItem;
    Connection1: TMenuItem;
    Controller1: TMenuItem;
    SETPARAMETERS1: TMenuItem;
    SAVESETTING1: TMenuItem;
    LOADSETTINGS1: TMenuItem;
    OPENPORT1: TMenuItem;
    CLOSEPORT1: TMenuItem;
    ComPort1: TComPort;
    Panel6: TPanel;
    Panel7: TPanel;
    Panel9: TPanel;
    Panel8: TPanel;
    StringGrid1: TStringGrid;
    Panel11: TPanel;
    Panel12: TPanel;
    Label4: TLabel;
    Bevel1: TBevel;
    Image5: TImage;
    Bevel2: TBevel;
    Image4: TImage;
    Bevel3: TBevel;
    Bevel4: TBevel;
    Image3: TImage;
    Image1: TImage;
    ComboBox2: TComboBox;
    Label2: TLabel;
    Edit1: TEdit;
    Label5: TLabel;
    Button1: TButton;
    Button2: TButton;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Panel1: TPanel;
    Bevel5: TBevel;
    Bevel6: TBevel;
    Image6: TImage;
    Bevel7: TBevel;
    Bevel8: TBevel;
    Image7: TImage;
    Image8: TImage;
    Panel4: TPanel;
    Panel10: TPanel;
    Button4: TButton;
    Image2: TImage;
    Panel3: TPanel;
    Panel14: TPanel;
    Option1: TMenuItem;
    ransaction1: TMenuItem;
    Panel16: TPanel;
    Edit3: TEdit;
    Edit4: TEdit;
    Label11: TLabel;
    Label12: TLabel;
    Button8: TButton;
    Panel15: TPanel;
    Label14: TLabel;
    Label15: TLabel;
    ComboBox3: TComboBox;
    Label10: TLabel;
    Edit2: TEdit;
    Button3: TButton;
    Label13: TLabel;
    Label9: TLabel;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Panel13: TPanel;
    Button10: TButton;
    Label3: TLabel;
    Label16: TLabel;
    Button9: TButton;
    Panel21: TPanel;
    Panel22: TPanel;
    Panel23: TPanel;
    Button11: TButton;
    Edit6: TEdit;
    Label17: TLabel;
    ComboBox4: TComboBox;
    StringGrid2: TStringGrid;
    Label18: TLabel;
    Panel19: TPanel;
    Memo1: TMemo;
    Panel20: TPanel;
    Label19: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    ComboBox5: TComboBox;
    Button12: TButton;
    Panel17: TPanel;
    Label54: TLabel;
    Label51: TLabel;
    Label1: TLabel;
    Panel18: TPanel;
    RadioButton10: TRadioButton;
    RadioButton11: TRadioButton;
    RadioButton12: TRadioButton;
    RadioButton13: TRadioButton;
    RadioButton14: TRadioButton;
    Edit5: TEdit;
    Edit7: TEdit;
    Button32: TButton;
    ComboBox1: TComboBox;
    Label24: TLabel;
    Label25: TLabel;
    procedure FormShow(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure Logout1Click(Sender: TObject);
    procedure Connection1Click(Sender: TObject);
    procedure Exit1Click(Sender: TObject);
    procedure Image3Click(Sender: TObject);
    procedure SETPARAMETERS1Click(Sender: TObject);
    procedure SAVESETTING1Click(Sender: TObject);
    procedure LOADSETTINGS1Click(Sender: TObject);
    procedure OPENPORT1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure ComPort1RxChar(Sender: TObject; Count: Integer);
    procedure FormCreate(Sender: TObject);
    procedure Button32Click(Sender: TObject);
    procedure RadioButton14Click(Sender: TObject);
    procedure Edit4KeyPress(Sender: TObject; var Key: Char);
    procedure Label23Click(Sender: TObject);
    procedure Label1Click(Sender: TObject);
    procedure Label1MouseEnter(Sender: TObject);
    procedure Label1MouseLeave(Sender: TObject);
    procedure CLOSEPORT1Click(Sender: TObject);
    procedure Panel9Click(Sender: TObject);
    procedure Image1Click(Sender: TObject);
    procedure StringGrid1KeyPress(Sender: TObject; var Key: Char);
    procedure StringGrid1SelectCell(Sender: TObject; ACol, ARow: Integer;
      var CanSelect: Boolean);
    procedure Edit1Change(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure ComboBox2Select(Sender: TObject);
    procedure Image8Click(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure ransaction1Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure ComboBox3Select(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Label18Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure ComboBox5Select(Sender: TObject);
    procedure Label24Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;
  start:integer=0;
  information, filepat:string;
  started, opened, edit, connected, loading, fan, port:boolean;
  s1r, s1c, incubatorn, eggnumber, connectnumber, loadpos:integer;
  reply, count:integer;
  hu, hd, tu, td:real;
  vent, rot, dd, hh, mn, mm, yy, controller, server, command:integer;
implementation

uses Unit1;

{$R *.dfm}
procedure setAsMainForm(aForm:Tform);
VAR
  p:Pointer;
begin
  p:=@Application.MainForm;
  Pointer(p^):=aform;
end;
procedure TForm2.FormShow(Sender: TObject);
begin
  setAsMainForm(form2);
  OPENPORT1Click(self.OPENPORT1);
  if(comport1.Connected=true) then panel5.caption:='CONNECTION 1 OPENED'
  else panel5.Caption:='CONNECTION 1 CLOSED'; start:=5;
  if(unit1.isanadmin=true) then view1.Visible:=true
  else view1.Visible:=false;
  button2click(self.Button1);
  button4click(self.Button1);
  Panel9Click(self.Panel9);
  button4click(self.ComboBox3);
  image8click(self.Image6);
  image8click(self.Image8);
  Button32Click(self.Button1);
end;

procedure TForm2.Timer1Timer(Sender: TObject);
var
  result:string;
begin
  if(start-1>=0) then start:=start-1
  else begin
    panel5.Caption:='';
    form1.Panel1.Caption:='';
  end;
  count:=count+1;
  if(count>=2) then begin
  if(loading) and (loadpos<>-1) then begin
    if(loadpos < stringgrid1.RowCount-1) then begin
      loadpos:=loadpos+1;
      button7click(self.Button7);
    end else begin
      panel5.Caption:='loading completed'; loading:=false; start:=4; panel4.Hide;
    end;
  end;
  count:=0;
  end;
  if(strtoint(label25.Caption)>0) then begin
    label25.Caption:=inttostr(strtoint(label25.Caption)-1);
  end;
  {if(comport1.Connected=false) and (form2.Visible=true) then begin
    image1.Visible:=not image1.Visible;
    OPENPORT1Click(self.OPENPORT1);
  end;    }
end;

procedure TForm2.Logout1Click(Sender: TObject);
begin
  form2.Hide;
  form1.show;
end;

procedure TForm2.Connection1Click(Sender: TObject);
begin
 panel21.Hide;
 if(panel17.Visible=true) then panel17.Visible:=false
 else panel17.Visible:=true;
end;

procedure TForm2.Exit1Click(Sender: TObject);
begin
application.Terminate;
end;

procedure TForm2.Image3Click(Sender: TObject);
begin
panel5.caption:='';
end;

procedure TForm2.SETPARAMETERS1Click(Sender: TObject);
begin
  comport1.ShowSetupDialog;
end;

procedure TForm2.SAVESETTING1Click(Sender: TObject);
begin
  ComPort1.StoreSettings(stRegistry, 'HKEY_LOCAL_MACHINE\Software\Dejan');
  panel5.Caption:='Settings Saved'; start:=2;
end;

procedure TForm2.LOADSETTINGS1Click(Sender: TObject);
begin
  ComPort1.LoadSettings(stRegistry, 'HKEY_LOCAL_MACHINE\Software\Dejan');
  panel5.Caption:='Settings Loaded'; start:=2;
end;

procedure TForm2.OPENPORT1Click(Sender: TObject);
begin
  if(comport1.Connected=false) then
   try
    comport1.Open;
    opened:=true; comport1.WriteStr('7');
    image1.Show; panel5.Caption:='Port opened'; start:=2;
   except on e:exception do begin
    opened:=false;
   end;
  end;
end;

procedure TForm2.FormClose(Sender: TObject; var Action: TCloseAction);
begin
 closeport1click(self.closeport1);
end;

procedure TForm2.ComPort1RxChar(Sender: TObject; Count: Integer);
function inforcontain():integer;
var
tempos:integer;
begin
  for tempos:=1 to length(information) do
    if(information[tempos]='*') then begin
      result:=tempos; exit;
    end;
    result:=0;
end;
var
incoming:string;
conp:integer;
begin
  comport1.ReadStr(incoming, Count);
  if(started=false) then begin
    if(incoming[1]='*') then begin
      if(incoming[length(incoming)]='#') then begin
         information:=copy(incoming, 2, length(incoming)-2);
         started:=false;
      end else begin
        information:=copy(incoming, 2, length(incoming)-1);
        started:=true; end
    end
  end else if((started=true) and (incoming[length(incoming)]='#')) then begin
    started:=false;
    information:=information+copy(incoming, 1, length(incoming)-1);
    conp:=inforcontain();
    if(conp<>0) then begin
      information:=copy(information, conp+1, length(information)-conp);
    end;
  end else information:=information+incoming;
  //check if the information has been received correctly
  if(started=false) then begin
    memo1.Lines.Add('Received: '+information);
    button3click(self.Button3);
  end;
end;
procedure TForm2.FormCreate(Sender: TObject);
begin
  filepat:=getcurrentdir+'\data';
  if(directoryexists(filepat)=false) then createdir(filepat);
  stringgrid1.Cells[0, 0]:='SN';
  stringgrid1.Cells[1, 0]:='L_TEMP';
  stringgrid1.Cells[2, 0]:='H_TEMP';
  stringgrid1.Cells[3, 0]:='L_HUMID';
  stringgrid1.Cells[4, 0]:='H_HUMID';
  stringgrid1.Cells[5, 0]:='N_ROT';
  stringgrid1.Cells[6, 0]:='N_VENT';
  stringgrid2.Cells[0, 0]:='SN';
  stringgrid2.Cells[1, 0]:='TIME';
  stringgrid2.Cells[2, 0]:='TEMPERATURE';
  stringgrid2.Cells[3, 0]:='HUMIDITY';

  loadsettings1click(self.LOADSETTINGS1);
end;

procedure TForm2.Button32Click(Sender: TObject);
type
TUser=Record
  name: string[30];                              //classs declare
  password: string[15];
  admin: boolean;
  end;
var
  userfile, tempuserfile:file of tuser;
  user: tuser;
  filename:string[20];
begin
  if(sender=button1) then begin
    combobox1.Items.Clear;
    combobox1.text:='';
    if(fileexists(filepat+'\users.bin')=true) then begin
      assignfile(userfile, filepat+'\users.bin');
      filemode:=fmopenread;
      reset(userfile);
      while not eof(userfile) do begin
        read(userfile, user);
        combobox1.Items.Add(user.name);
      end;
      closefile(userfile);
    end;
    if(combobox1.Items.Count>0) then combobox1.ItemIndex:=0;
    exit;
  end;
  if (radiobutton10.Checked=true) then begin
    if(combobox1.Text='') then begin
      panel5.Caption:='Enter Name'; combobox1.SetFocus; start:=4; exit;
    end;
    if(combobox1.Items.IndexOf(combobox1.Text)>=0) then begin
      panel5.Caption:=combobox1.Text+' is already a User'; combobox1.SetFocus; start:=4; exit;
    end;
    if (edit5.Text='') then begin
      panel5.caption:='Enter password'; edit5.SetFocus; start:=3; exit;
    end;
    if edit7.Text='' then begin
      panel5.caption:='Confirm password'; edit7.SetFocus; start:=3; exit;
    end;
    if(edit5.Text<>edit7.text) then begin
      panel5.caption:='Password did not match'; edit7.SetFocus; start:=3; exit;
    end;
    user.admin:=false;
    user.name:=combobox1.Text;
    user.password:=edit5.text;  //max size 15
    if(fileexists(filepat+'\users.bin')=true) then begin
      assignfile(tempuserfile, filepat+'\temp.bin');
      rewrite(tempuserfile);
      write(tempuserfile, user);
      assignfile(userfile, filepat+'\users.bin');
      filemode:=fmopenread;
      reset(userfile);
      while not eof(userfile) do begin
        read(userfile, user);
        write(tempuserfile, user);
      end;
      closefile(userfile);
      closefile(tempuserfile);
      rewrite(userfile);
      reset(tempuserfile);
      while not eof(tempuserfile) do begin
        read(tempuserfile, user);
        write(userfile, user);
      end;
      closefile(tempuserfile);
      closefile(userfile);
    end else begin
      assignfile(userfile, filepat+'\users.bin');
      rewrite(userfile);
      write(userfile, user);
      closefile(userfile);
    end;
    combobox1.Items.Add(combobox1.Text);
    panel5.caption:= uppercase(user.name)+' Has been added successfully';
  exit;
  end;
  if (radiobutton11.Checked=true) or (radiobutton12.Checked=true) or
    (radiobutton14.Checked=true) then begin
    if(combobox1.Items.IndexOf(combobox1.Text)<0) then begin
      panel5.Caption:=uppercase(combobox1.Text)+' is not a user'; combobox1.SetFocus; start:=3; exit;
    end;
    if lowercase(combobox1.Text)=lowercase(theuser) then begin
      panel5.caption:='You cannot manipulate your user file in any way';
      combobox1.SetFocus; start:=3; exit;
    end;
    if (radiobutton11.Checked=true) then begin
      case messagedlg('Are you sure you want to remove '+#13#10+uppercase(combobox1.Text)+
      #13#10, MTINFORMATION,[MBYES, MBNO, MBCANCEL], 0) OF
        mryes: begin
          assignfile(tempuserfile, filepat+'\temp.bin');
          rewrite(tempuserfile);
          assignfile(userfile, filepat+'\users.bin');
          filemode:=fmopenread;
          reset(userfile);
          while not eof(userfile) do begin
            read(userfile, user);
            if(lowercase(combobox1.Text)<>lowercase(user.name)) then write(tempuserfile, user);
          end;
          closefile(userfile);
          closefile(tempuserfile);
          rewrite(userfile);
          reset(tempuserfile);
          while not eof(tempuserfile) do begin
            read(tempuserfile, user);
            write(userfile, user);
          end;
          closefile(tempuserfile);
          closefile(userfile);
          panel5.caption:=uppercase(combobox1.Text)+' removed successfully';
          combobox1.Items.Delete(combobox1.Items.IndexOf(combobox1.Text));
        end;
        mrno: panel5.caption:=uppercase(combobox1.Text)+' not removed';
        mrcancel: panel5.caption:=uppercase(combobox1.Text)+' not removed';
      end;
      exit;
    end;
    if (radiobutton12.Checked=true) or (radiobutton14.Checked=true) then begin
      assignfile(tempuserfile, filepat+'\temp.bin');
      rewrite(tempuserfile);
      assignfile(userfile, filepat+'\users.bin');
      filemode:=fmopenread;
      reset(userfile);
      while not eof(userfile) do begin
        read(userfile, user);
        if(lowercase(combobox1.Text)=lowercase(user.name)) then begin
          if user.admin=true then begin
            if radiobutton12.Checked=true then begin
              panel5.caption:=uppercase(user.name)+' is already an administrator';
            end;
            if radiobutton14.Checked=true then begin
              user.admin:=false;
              write(tempuserfile, user);
              panel5.caption:=uppercase(user.name)+' deprived of admin previledges';
            end;
          end else begin
            if radiobutton14.Checked=true then begin
              panel5.caption:=uppercase(user.name)+' is not an administrator';
            end;
            if radiobutton12.Checked=true  then begin
              user.admin:=true;
              write(tempuserfile, user);
              panel5.caption:=uppercase(user.name)+' has been made an administrator';
            end;
          end;
        end else write(tempuserfile, user);
      end;
      closefile(userfile);
      closefile(tempuserfile);
      rewrite(userfile);
      reset(tempuserfile);
      while not eof(tempuserfile) do begin
        read(tempuserfile, user);
        write(userfile, user);
      end;
      closefile(tempuserfile);
      closefile(userfile);
    end;
  end;
end;
procedure TForm2.RadioButton14Click(Sender: TObject);
begin
  panel5.caption:='';
  if radiobutton10.Checked=true then  begin //add user
    edit5.show; edit7.show; label54.Show; label1.Show;
  end;
  if radiobutton11.Checked=true then  begin  //remove user
    edit5.hide; edit7.hide; label54.hide; label1.hide;
  end;
  if radiobutton12.Checked=true then  begin //add admin
    edit5.hide; edit7.hide; label54.hide; label1.hide;
  end;
  if radiobutton14.Checked=true then  begin  //remove admin
    edit5.hide; edit7.hide; label54.hide; label1.hide;
  end;
end;

procedure TForm2.Edit4KeyPress(Sender: TObject; var Key: Char);
begin
  if(ord(key)=13) then begin
    key:=#0;
    button32click(self.Button32);
  end;
end;

procedure TForm2.Label23Click(Sender: TObject);
function its(wha:integer):string;
var
  i, tempd:integer;
  temps:string;
  ch:char;
begin
  i:=2; temps:='';
    while(i>0) do begin
      temps:=temps+inttostr(wha mod 10);
      wha:=wha div 10;
      i:=i-1;
    end;
    ch:=temps[1];
    temps[1]:=temps[2];
    temps[2]:=ch;
    result:=temps;
end;
begin
end;

procedure TForm2.Label1Click(Sender: TObject);
begin
  panel17.Hide;
end;

procedure TForm2.Label1MouseEnter(Sender: TObject);
begin
  label1.Font.Color:=clfuchsia;
end;

procedure TForm2.Label1MouseLeave(Sender: TObject);
begin
  label1.Font.Color:=clwhite;
end;

procedure TForm2.CLOSEPORT1Click(Sender: TObject);
begin
  if(opened=true) then begin
    try
      comport1.Connected:=false;
      opened:=false; panel5.Caption:='Port Closed'; start:=2;
    except on e: exception do begin
      opened:=false;
      showmessage('Warning!!!! Transmitter disconnected on use Warning!!1'+#13#10+
                  'Do not disconnect transmitter when application is still running');
      end;
    end;
  end;
end;

procedure TForm2.Panel9Click(Sender: TObject);
begin
  panel21.Hide;
  panel21.Hide;
  panel7.Color:=clbtnhighlight; panel9.Color:=clbtnhighlight;
  panel6.Hide; panel1.Hide;
  if(sender=panel9) then begin
    panel9.Color:=clbtnface;   image8click(self.Image8);
    panel1.Show; panel4.Show; panel8.Hide;
  end else if(sender=panel7) then begin
    panel7.Color:=clbtnface;   image1click(self.Image1);
    panel6.Show; panel4.Hide; panel8.Show;
  end;
end;

procedure TForm2.Image1Click(Sender: TObject);
begin
  if(sender=image1) and (bevel4.Visible=true) then exit;
  if(sender=image3) and (bevel3.Visible=true) then exit;
  if(sender=image4) and (bevel2.Visible=true) then exit;
  if(sender=image5) and (bevel1.Visible=true) then exit;
  panel21.Hide;
  bevel4.Hide; bevel3.Hide; bevel2.Hide; bevel1.Hide;  //adjust bevel
  combobox2.Style:=csdropDownList;
  button6.Hide;                         //adjust combobox2
  if(sender=image1) then begin //View
    button6.Show;
    button2.Caption:='NONE';
    panel3.Caption:='View';  edit:=false;
    bevel4.Show; edit1.Hide; label5.Show;
  end else if(sender=image3) then begin //new
    button2.Caption:='SUBMIT';
    panel3.Caption:='New';   edit:=true;
    combobox2.Style:=csdropDown;
    bevel3.Show; edit1.Show; label5.Hide;
  end else if(sender=image4) then begin //edit
    button2.Caption:='SUBMIT';
    panel3.Caption:='Edit';  edit:=true;
    bevel2.Show; edit1.Show; label5.Hide;
  end else if(sender=image5) then begin //delete
    button2.Caption:='OK';
    panel3.Caption:='Delete'; edit:=false;
    bevel1.Show;  edit1.Hide; label5.Show;
  end;
end;

procedure TForm2.StringGrid1KeyPress(Sender: TObject; var Key: Char);
var
  i:integer;
  text:String;
begin
  if(s1r=0) or (s1c=0) then exit;
  if(edit=false) then begin
    exit;
  end;
  i:=ord(key);
  if((i<48) or (i>57)) and (i<>13) and (i<>46) and (i<>8) then begin
    beep; exit;
  end;
  if((s1c=5) or (s1c=6)) and (i=46) then exit;
  text:=stringGrid1.Cells[s1c, s1r];
  if(length(text)=4) and (i<>8) then begin
    panel5.Caption:='Maximun length field reached'; start:=2;
    exit;
  end;
  if(ord(key)=8) then begin
    if(length(text)>0) then text:=copy(text, 1, length(text)-1);
    stringGrid1.Cells[s1c, s1r]:=text;
  end else begin
    stringGrid1.Cells[s1c, s1r]:=text+key;
  end;
end;
procedure TForm2.StringGrid1SelectCell(Sender: TObject; ACol,
  ARow: Integer; var CanSelect: Boolean);
begin
  s1r:=arow;
  s1c:=Acol;
end;

procedure TForm2.Edit1Change(Sender: TObject);
var
  text:string;
  number, code:integer;
begin
  val(edit1.Text, number, code);
  if(code=0) and (number>=0) then begin
    stringgrid1.RowCount:=number+1;
    label5.Caption:=edit1.Text;
    for code:=1 to number+1 do stringgrid1.Cells[0, code]:=inttostr(code);
    button2.Enabled:=true;
  end else begin
    button2.Enabled:=false;
    stringgrid1.RowCount:=1;
  end;
end;

procedure TForm2.Button2Click(Sender: TObject);
type
Teggs=record
  sn:integer;
  name:string[30];
  days:integer;
  date:tdate;
end;
Teggsrecord=record
  sn:integer;
  day:integer;
  htemp:real;
  ltemp:real;
  hhumid:real;
  lhumid:real;
  nrotation:integer;
  nventilation:integer;
end;
var
  eggs:teggs;
  eggsfile, tempeggsfile:file of teggs;
  eggsrecord:teggsrecord;
  eggsrecordfile, tempeggsrecordfile:file of teggsrecord;
  i, j:integer;
begin
  if(sender=button1) then begin
    label7.Caption:='0';
    label6.Caption:='0';
    label5.Caption:='0';
    edit1.Text:='0';
    combobox2.Items.Clear; combobox2.Style:=csdropdownlist;
    stringgrid1.RowCount:=1;
    if(fileexists(filepat+'\eggs.bin')=true) then begin
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        label7.Caption:=inttostr(strtoint(label7.Caption)+1);
        combobox2.Items.Add(eggs.name);
      end;
      closefile(eggsfile);
      combobox2.ItemIndex:=0;
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        if(combobox2.Text=eggs.name) then begin
          stringgrid1.RowCount:=eggs.days+1;
          label5.Caption:=inttostr(eggs.days);
          edit1.Text:=label5.Caption;
          eggnumber:=eggs.sn;
          label6.Caption:=inttostr(eggs.sn);
        end;
      end;
      closefile(eggsfile);
      if(fileexists(filepat+'\eggsrecord.bin')=true) then begin
        assignfile(eggsrecordfile, filepat+'\eggsrecord.bin');
        reset(eggsrecordfile);
        while not eof(eggsrecordfile) do begin
          read(eggsrecordfile, eggsrecord);
          if(eggsrecord.sn=eggnumber) then begin
            stringgrid1.Cells[0, eggsrecord.day]:=inttostr(eggsrecord.day);
            stringgrid1.Cells[1, eggsrecord.day]:=floattostr(eggsrecord.ltemp);
            stringgrid1.Cells[2, eggsrecord.day]:=floattostr(eggsrecord.htemp);
            stringgrid1.Cells[3, eggsrecord.day]:=floattostr(eggsrecord.lhumid);
            stringgrid1.Cells[4, eggsrecord.day]:=floattostr(eggsrecord.hhumid);
            stringgrid1.Cells[5, eggsrecord.day]:=inttostr(eggsrecord.nrotation);
            stringgrid1.Cells[6, eggsrecord.day]:=inttostr(eggsrecord.nventilation);
          end;
        end;
        closefile(eggsrecordfile);
      end;
    end else begin
      stringgrid1.RowCount:=1;
    end;
    label8.Caption:=label6.Caption+' /'+label7.Caption;
  exit;
  end;
  if(sender=combobox2) then begin
    if(combobox2.Items.IndexOf(combobox2.Text)<0) then exit;
    if(fileexists(filepat+'\eggs.bin')=true) then begin
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        if(eggs.name=combobox2.Text) then begin
          label5.Caption:=inttostr(eggs.days);
          edit1.Text:=label5.Caption;
          eggnumber:=eggs.sn;
          label6.Caption:=inttostr(eggs.sn);
          break;
        end;
      end;
      closefile(eggsfile);
      if(fileexists(filepat+'\eggsrecord.bin')=true) then begin
        assignfile(eggsrecordfile, filepat+'\eggsrecord.bin');
        reset(eggsrecordfile);
        while not eof(eggsrecordfile) do begin
          read(eggsrecordfile, eggsrecord);
          if(eggsrecord.sn=eggnumber) then begin
            stringgrid1.Cells[0, eggsrecord.day]:=inttostr(eggsrecord.day);
            stringgrid1.Cells[1, eggsrecord.day]:=floattostr(eggsrecord.ltemp);
            stringgrid1.Cells[2, eggsrecord.day]:=floattostr(eggsrecord.htemp);
            stringgrid1.Cells[3, eggsrecord.day]:=floattostr(eggsrecord.lhumid);
            stringgrid1.Cells[4, eggsrecord.day]:=floattostr(eggsrecord.hhumid);
            stringgrid1.Cells[5, eggsrecord.day]:=inttostr(eggsrecord.nrotation);
            stringgrid1.Cells[6, eggsrecord.day]:=inttostr(eggsrecord.nventilation);
          end;
        end;
        closefile(eggsrecordfile);
      end;
    end;
    label8.Caption:=label6.Caption+' /'+label7.Caption;
    exit;
  end;
  if(sender=button2) then begin
    if(bevel4.Visible=true) then exit;
    if(bevel3.Visible=true) then begin
      if(combobox2.Text='') then begin
        panel5.Caption:='Enter egg name'; start:=3; exit;
      end;
      if(combobox2.Items.IndexOf(combobox2.Text)>=0) then begin
        panel5.Caption:='An egg with this name exist already'; start:=3; exit;
      end;
    end;
    if(bevel2.Visible=true) or (bevel1.Visible=true) then begin
      if(combobox2.Text='') then begin
        if(bevel2.Visible=true) then panel5.Caption:='Select egg to edit'
        else panel5.Caption:='Select egg to delete';
        start:=3; exit;
      end;
      if(combobox2.Items.IndexOf(combobox2.Text)<0) then begin
        panel5.Caption:='Selected name does not exist'; start:=3; exit;
      end;
    end;
    if(bevel1.Visible=true) then begin  //deleting
      case messagedlg('Are you certain to delete record of '+combobox2.Text, mtwarning,
        [mbno, mbyes, mbcancel], 0) of
        mrcancel: begin panel5.Caption:= combobox2.Text+' not deleted'; start:=3; exit; end;
        mrno: begin panel5.Caption:= combobox2.Text+' not deleted'; start:=3; exit; end;
      end;

      if(fileexists(filepat+'\eggs.bin')=false) then exit;
      if(fileexists(filepat+'\eggsrecord.bin')=false) then exit;
      eggnumber:=strtoint(label6.Caption);
      assignfile(tempeggsfile, filepat+'\temp\temp.bin');
      rewrite(tempeggsfile);
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        if(eggs.sn<>eggnumber) then begin
          if(eggs.sn>eggnumber) then eggs.sn:=eggs.sn-1;
          write(tempeggsfile, eggs);
        end;
      end;
      closefile(eggsfile);
      closefile(tempeggsfile);
      reset(tempeggsfile);
      rewrite(eggsfile);
      while not eof(tempeggsfile) do begin
        read(tempeggsfile, eggs);
        write(eggsfile, eggs);
      end;
      closefile(eggsfile);
      closefile(tempeggsfile);
      //done editing file
      //start editing record
      assignfile(tempeggsrecordfile, filepat+'\temp\temp.bin');
      assignfile(eggsrecordfile, filepat+'\eggsrecord.bin');
      reset(eggsrecordfile);
      rewrite(tempeggsrecordfile);

      while not eof(eggsrecordfile) do begin
        read(eggsrecordfile, eggsrecord);
        if(eggsrecord.sn<>eggnumber) then begin
          if(eggsrecord.sn>eggnumber) then eggsrecord.sn:=eggsrecord.sn-1;
          write(tempeggsrecordfile, eggsrecord);
        end;
      end;
      closefile(eggsrecordfile);
      closefile(tempeggsrecordfile);
      reset(tempeggsrecordfile);
      rewrite(eggsrecordfile);
      while not eof(tempeggsrecordfile) do begin
        read(tempeggsrecordfile, eggsrecord);
        write(eggsrecordfile, eggsrecord);
      end;
      closefile(tempeggsrecordfile);
      closefile(eggsrecordfile);
      panel5.Caption:=combobox2.Text+' Deleted successfuly'; start:=3;
      combobox2.Items.Delete(combobox2.Items.IndexOf(combobox2.Text));
      label7.Caption:=inttostr(strtoint(label7.Caption)-1);
      if(combobox2.Items.Count=0) then begin
        stringgrid1.RowCount:=1;
        label6.Caption:='0'; label7.Caption:='0';
        label8.Caption:='0 /0';
        deletefile(filepat+'\eggsrecord.bin');
        deletefile(filepat+'\eggs.bin');
        combobox2.Text:='';
        edit1.Text:='0'; label1.Caption:='0';
      end else begin
        combobox2.ItemIndex:=0; button2click(self.ComboBox2);
      end;
      exit;
    end;
    if(bevel2.Visible=true) then begin  //editing
      if(fileexists(filepat+'\eggs.bin')=false) then exit;
      if(fileexists(filepat+'\eggsrecord.bin')=false) then exit;
      eggnumber:=strtoint(label6.Caption);
      assignfile(tempeggsfile, filepat+'\temp\temp.bin');
      rewrite(tempeggsfile);
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        if(eggs.sn=eggnumber) then begin
          eggs.days:=strtoint(edit1.Text);
        end;
        write(tempeggsfile, eggs);
      end;
      closefile(eggsfile);
      closefile(tempeggsfile);
      reset(tempeggsfile);
      rewrite(eggsfile);
      while not eof(tempeggsfile) do begin
        read(tempeggsfile, eggs);
        write(eggsfile, eggs);
      end;
      closefile(eggsfile);
      closefile(tempeggsfile);
      //done editing file
      //start editing record
      assignfile(tempeggsrecordfile, filepat+'\temp\temp.bin');
      assignfile(eggsrecordfile, filepat+'\eggsrecord.bin');
      rewrite(tempeggsrecordfile);

      for i:=1 to stringgrid1.RowCount-1 do begin
        eggsrecord.sn:=eggnumber;
        eggsrecord.day:=strtoint(stringgrid1.Cells[0, i]);
        if(stringgrid1.Cells[1, i]='') then eggsrecord.ltemp:=0
        else eggsrecord.ltemp:=strtofloat(stringgrid1.Cells[1, i]);
        if(stringgrid1.Cells[2, i]='') then eggsrecord.htemp:=0
        else eggsrecord.htemp:=strtofloat(stringgrid1.Cells[2, i]);
        if(stringgrid1.Cells[3, i]='') then eggsrecord.lhumid:=0
        else eggsrecord.lhumid:=strtofloat(stringgrid1.Cells[3, i]);
        if(stringgrid1.Cells[4, i]='') then eggsrecord.hhumid:=0
        else eggsrecord.hhumid:=strtofloat(stringgrid1.Cells[4, i]);
        if(stringgrid1.Cells[5, i]='') then eggsrecord.nrotation:=0
        else eggsrecord.nrotation:=strtoint(stringgrid1.Cells[5, i]);
        if(stringgrid1.Cells[6, i]='') then eggsrecord.nventilation:=0
        else eggsrecord.nventilation:=strtoint(stringgrid1.Cells[6, i]);
        write(tempeggsrecordfile, eggsrecord);
      end;
      reset(eggsrecordfile);
      while not eof(eggsrecordfile) do begin
        read(eggsrecordfile, eggsrecord);
        if(eggsrecord.sn<>eggnumber) then write(tempeggsrecordfile, eggsrecord);
      end;
      closefile(eggsrecordfile);
      closefile(tempeggsrecordfile);
      reset(tempeggsrecordfile);
      rewrite(eggsrecordfile);
      while not eof(tempeggsrecordfile) do begin
        read(tempeggsrecordfile, eggsrecord);
        write(eggsrecordfile, eggsrecord);
      end;
      closefile(tempeggsrecordfile);
      closefile(eggsrecordfile);
      button2click(self.ComboBox2);
      panel5.Caption:=combobox2.Text+' edited successfuly';  start:=3;
      exit;
    end;

    if(directoryexists(filepat+'\temp')=false) then createdir(filepat+'\temp');
    //get the number of ggs
    eggnumber:=0;
    if(fileexists(filepat+'\eggs.bin')=true) then begin
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        if(eggnumber<eggs.sn) then eggnumber:=eggs.sn;
      end;
      closefile(eggsfile);
    end;
    eggnumber:=eggnumber+1;
    //done with egg number
    assignfile(tempeggsfile, filepat+'\temp\eggs.bin');
    assignfile(eggsfile, filepat+'\eggs.bin');
    rewrite(tempeggsfile);
    eggs.sn:=eggnumber;
    eggs.name:=combobox2.Text;
    eggs.days:=strtoint(edit1.Text);
    eggs.date:=date;
    write(tempeggsfile, eggs);
    if(fileexists(filepat+'\eggs.bin')=true) then begin
      assignfile(eggsfile, filepat+'\eggs.bin');
      reset(eggsfile);
      while not eof(eggsfile) do begin
        read(eggsfile, eggs);
        write(tempeggsfile, eggs);
      end;
      closefile(eggsfile);
    end;
    closefile(tempeggsfile);
    reset(tempeggsfile);
    rewrite(eggsfile);
    while not eof(tempeggsfile) do begin
      read(tempeggsfile, eggs);
      write(eggsfile, eggs);
    end;
    closefile(tempeggsfile);
    closefile(eggsfile);
    assignfile(tempeggsrecordfile, filepat+'\temp\temp.bin');
    assignfile(eggsrecordfile, filepat+'\eggsrecord.bin');
    rewrite(tempeggsrecordfile);
    for i:=1 to stringgrid1.RowCount-1 do begin
      eggsrecord.sn:=eggnumber;
      eggsrecord.day:=strtoint(stringgrid1.Cells[0, i]);
      if(stringgrid1.Cells[1, i]='') then eggsrecord.ltemp:=0
      else eggsrecord.ltemp:=strtofloat(stringgrid1.Cells[1, i]);
      if(stringgrid1.Cells[2, i]='') then eggsrecord.htemp:=0
      else eggsrecord.htemp:=strtofloat(stringgrid1.Cells[2, i]);
      if(stringgrid1.Cells[3, i]='') then eggsrecord.lhumid:=0
      else eggsrecord.lhumid:=strtofloat(stringgrid1.Cells[3, i]);
      if(stringgrid1.Cells[4, i]='') then eggsrecord.hhumid:=0
      else eggsrecord.hhumid:=strtofloat(stringgrid1.Cells[4, i]);
      if(stringgrid1.Cells[5, i]='') then eggsrecord.nrotation:=0
      else eggsrecord.nrotation:=strtoint(stringgrid1.Cells[5, i]);
      if(stringgrid1.Cells[6, i]='') then eggsrecord.nventilation:=0
      else eggsrecord.nventilation:=strtoint(stringgrid1.Cells[6, i]);
      write(tempeggsrecordfile, eggsrecord);
    end;
    if(fileexists(filepat+'\eggsrecord.bin')=true) then begin
      reset(eggsrecordfile);
      while not eof(eggsrecordfile) do begin
        read(eggsrecordfile, eggsrecord);
        write(tempeggsrecordfile, eggsrecord);
      end;
      closefile(eggsrecordfile);
    end;
    closefile(tempeggsrecordfile);
    rewrite(eggsrecordfile);
    reset(tempeggsrecordfile);
    while not eof(tempeggsrecordfile) do begin
      read(tempeggsrecordfile, eggsrecord);
      write(eggsrecordfile, eggsrecord);
    end;
    closefile(tempeggsrecordfile);
    closefile(eggsrecordfile);
    combobox2.Items.Add(combobox2.Text);
    button2click(self.ComboBox2);
    label7.Caption:=inttostr(strtoint(label7.Caption)+1);
    label8.Caption:=label6.Caption+' /'+label7.Caption;
    panel5.Caption:=eggs.name +' added successfuly '; start:=3;
  end;
end;

procedure TForm2.ComboBox2Select(Sender: TObject);
begin
  button2click(self.ComboBox2);
end;

procedure TForm2.Image8Click(Sender: TObject);
begin
  if(sender=image8) and (bevel8.Visible=true) then exit;
  if(sender=image7) and (bevel7.Visible=true) then exit;
  if(sender=image6) and (bevel6.Visible=true) then exit;
  if(sender=image2) and (bevel5.Visible=true) then exit;
  panel21.Hide;
  button9.Hide;
  bevel5.Hide; bevel6.Hide; bevel7.Hide; bevel8.Hide;  //adjust bevel
  combobox3.Style:=csdropDownList;                   //adjust combobox2
  if(sender=image8) then begin //View
    button9.Show;
    if(connected=true) then begin
      panel16.Enabled:=true;
      button4.Caption:='DISCONNECT'
    end else begin
      panel16.Enabled:=true;
      button4.Caption:='CONNECT';
    end;
    panel14.Caption:='View'; bevel8.Show;
    label10.Show; edit2.Hide;
  end else if(sender=image7) then begin //new
    button4.Caption:='SUBMIT';
    panel14.Caption:='New';   edit:=true;
    combobox3.Style:=csdropDown; bevel7.Show;
    label10.Hide; edit2.Show;
  end else if(sender=image6) then begin //edit
    button4.Caption:='SUBMIT'; 
    panel14.Caption:='Edit';  edit:=true;
    bevel6.Show; label10.Hide; edit2.Show;
  end else if(sender=image2) then begin //delete
    button4.Caption:='OK'; 
    panel14.Caption:='Delete'; edit:=false;
    bevel5.Show; label10.Show; edit2.Hide;
  end;
end;
procedure TForm2.Edit2Change(Sender: TObject);
var
  text:string;
  number, code:integer;
begin
  val(edit2.Text, number, code);
  if(code=0) and (number>=0) then begin
    stringgrid1.RowCount:=number+1;
    label10.Caption:=edit2.Text;
  end else begin
    edit2.Text:='0';
    stringgrid1.RowCount:=1;
  end;
end;
procedure TForm2.Button4Click(Sender: TObject);
type
tincubator=record
  name:string[30];
  sn:integer;
  days:integer;
  loaddate:tdate;
  capacity:integer;
  incubating:boolean;
end;
var
  incubator:tincubator;
  incubatorfile, tempincubatorfile:file of tincubator;
  i, j:integer;
  deleted, incubate:boolean;
  ddd, mnn, mmm, hhh, yyy, sss, mss:word;
begin
  if(sender=button1) then begin
    combobox3.Items.Clear; combobox3.Style:=csdropdownlist;
    if(fileexists(filepat+'\incubator.bin')=true) then begin
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        combobox3.Items.Add(incubator.name);
      end;
      closefile(incubatorfile);
      combobox3.ItemIndex:=0;
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(combobox3.Text=incubator.name) then begin
          label10.Caption:=inttostr(incubator.capacity);
          edit2.Text:=label10.Caption;
          incubatorn:=incubator.sn;
          if(incubator.incubating=true) then begin
           label16.Caption:='YES';
           button10.Caption:='STOP';
          end else begin
           label16.Caption:='NO';
           button10.Caption:='START';
          end;
        end;
      end;
      closefile(incubatorfile);
      exit;
    end;
  end;
  if(sender=combobox3) then begin
    if(combobox3.Items.IndexOf(combobox3.Text)<0) then exit;
    if(fileexists(filepat+'\incubator.bin')=true) then begin
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(incubator.name=combobox3.Text) then begin
          label10.Caption:=inttostr(incubator.capacity);
          edit2.Text:=label10.Caption;
          incubatorn:=incubator.sn;
          if(incubator.incubating=true) then begin
           label16.Caption:='YES';
           button10.Caption:='STOP';
          end else begin
           label16.Caption:='NO';
           button10.Caption:='START';
          end;
          break;
        end;
      end;
      closefile(incubatorfile);
    exit;
    end;
  end;
  if(sender=button10) then begin
    if(connected=false) then begin
      panel5.Caption:='INCUBATOR NOT CONNECTED'; start:=3; exit;
    end;
    case messagedlg( 'ARE YOU CERTAIN TO '+button10.Caption+' INCUBATING', mtwarning, [mbcancel, mbyes, mbno], 0) of
    mrcancel: begin panel5.Caption:='COMMAND CANCELED'; start:=3; exit; end;
    mrno:begin panel5.Caption:='COMMAND CANCELED'; start:=3; exit; end;
    end;
    if(fileexists(filepat+'\incubator.bin')=false) then exit;
      assignfile(tempincubatorfile, filepat+'\temp\temp.bin');
      rewrite(tempincubatorfile);
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(incubator.name=combobox3.Text) then begin
          if(button10.Caption='START') then begin
            label16.Caption:='YES';
            button10.Caption:='STOP';
            incubator.incubating:=true;
            incubate:=true;
          end else begin
            incubator.incubating:=false;
            label16.Caption:='NO';
            button10.Caption:='START';
            incubate:=false;
          end;
          incubator.loaddate:=date;
        end;
        write(tempincubatorfile, incubator);
      end;
      closefile(incubatorfile);
      closefile(tempincubatorfile);
      reset(tempincubatorfile);
      rewrite(incubatorfile);
      while not eof(tempincubatorfile) do begin
        read(tempincubatorfile, incubator);
        write(incubatorfile, incubator);
      end;
      closefile(incubatorfile);
      closefile(tempincubatorfile);
      if(incubate=false) then begin
        command:=0;
        button5click(self.Button5);
      end else begin
        command:=1;
        decodedate(date, yyy, mnn, ddd);
        decodetime(now, hhh, mmm, sss, mss);
        mm:=mmm; mn:=mnn; hh:=hhh; yyy:=yy; dd:=ddd;
        button5click(self.button5);
      end;
      exit;
  end;
  if(sender=button4) then begin
    if(loading=true) and (panel8.Visible=true) then begin
        if(incubatorn<>1)then begin
        panel5.Caption:='INCUBATOR NOT FOUND'; start:=4; exit;
      end;
      case messagedlg('THIS WILL OVERIDE THE OLD EGG DATA IN THE INCUBATOR! CONTINUE??', mtwarning, [mbno, mbyes, mbcancel], 0) of
        mrno: panel5.Caption:='LOADING CANCELED';
        mrcancel:panel5.Caption:='LOADING CANCELED';
        mryes: begin
          panel5.Caption:='LOADING PLEASE WAIT...';
          START:=30; loadpos:=1;
          loading:=true;
          button7click(self.Button7);
        end;
      end;
      start:=3; panel4.Hide;
      exit;
    end;
    if(bevel8.Visible=true) then begin
      if(incubatorn<>1)then begin
        panel5.Caption:='INCUBATOR NOT FOUND'; start:=4; exit;
      end;
      if(comport1.Connected=true) then begin
        if(connected=true) then begin
          comport1.WriteStr('7');
          button4.Caption:='CONNECT';
          panel5.Caption:='INCUBATOR DISCONNECTTING...'; start:=5;
          label9.Caption:='OFFLINE'; label13.Caption:='OFFLINE';
          panel16.Enabled:=false;
          connected:=false;
        end else begin
        stringgrid2.rowCount:=49;
          for i:=1 to 48 do begin
           stringgrid2.Cells[0, i]:=inttostr(i);
           stringgrid2.Cells[1, i]:='0';
           stringgrid2.Cells[2, i]:='0';
           stringgrid2.Cells[3, i]:='0';
         end;
          comport1.WriteStr('6');
          button4.Caption:='DISCONNECT';
          panel5.Caption:='INCUBATOR CONNECTING....'; start:=5;
          connected:=true;
          panel16.Enabled:=true;
        end
       end else begin
        panel5.Caption:='PROGRAM MODULE NOT CONNECTED'; start:=5;
      end;
      exit;
    end;
    if(bevel7.Visible=true) then begin
      if(combobox3.Text='') then begin
        panel5.Caption:='Enter incubator name'; start:=3; exit;
      end;
      if(combobox3.Items.IndexOf(combobox3.Text)>=0) then begin
        panel5.Caption:='Incubator with this name exist already'; start:=3; exit;
      end;
      if(edit2.Text='') or (edit2.Text='0') then begin
        panel5.Caption:='Enter capacity'; edit2.SetFocus; start:=3;
      end;
    end;
    if(bevel6.Visible=true) or (bevel5.Visible=true) then begin
      if(combobox3.Text='') then begin
        if(bevel6.Visible=true) then panel5.Caption:='Select incubator to edit'
        else panel5.Caption:='Select incubator to delete';
        start:=3; exit;
      end;
      if(combobox3.Items.IndexOf(combobox3.Text)<0) then begin
        panel5.Caption:='Selected name does not exist'; start:=3; exit;
      end;
    end;
    if(bevel5.Visible=true) then begin  //deleting
      case messagedlg('Are you certain to delete record of '+combobox3.Text, mtwarning,
        [mbno, mbyes, mbcancel], 0) of
        mrcancel: begin panel5.Caption:= combobox3.Text+' not deleted'; start:=3; exit; end;
        mrno: begin panel5.Caption:= combobox3.Text+' not deleted'; start:=3; exit; end;
      end;
      if(fileexists(filepat+'\incubator.bin')=false) then exit;
      assignfile(tempincubatorfile, filepat+'\temp\temp.bin');
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      deleted:=true;
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(incubator.name=combobox3.Text) then begin
          if(incubator.incubating=true) then begin
            panel5.Caption:='Sorry You cannot delete this incubator because it is incubating'; start:=4;
            deleted:=true;
            //deleted:=false;
          end;
        end;
      end;

      if(deleted=true) then begin
        rewrite(tempincubatorfile);
        reset(incubatorfile);
        while not eof(incubatorfile) do begin
          read(incubatorfile, incubator);
          if(incubator.name<>combobox3.Text) then begin
            if(incubator.sn>incubatorn) then incubator.sn:=incubator.sn-1;
            write(tempincubatorfile, incubator);
          end
         end;
         closefile(incubatorfile);
         closefile(tempincubatorfile);
         reset(tempincubatorfile);
         rewrite(incubatorfile);
         while not eof(tempincubatorfile) do begin
          read(tempincubatorfile, incubator);
          write(incubatorfile, incubator);
        end;
        closefile(tempincubatorfile);
        combobox3.Items.Delete(combobox3.ItemIndex);
        combobox3.ItemIndex:=0;
       end;
       closefile(incubatorfile);
       button4click(self.ComboBox3);
      //done editing file
      exit;
    end;
    if(bevel6.Visible=true) then begin  //editing
      if(fileexists(filepat+'\incubator.bin')=false) then exit;
      assignfile(tempincubatorfile, filepat+'\temp\temp.bin');
      rewrite(tempincubatorfile);
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      if(edit2.Text='') or (edit2.Text='0') then begin
        panel5.Caption:='Enter capacity'; edit2.SetFocus; start:=3;
      end;
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(incubator.name=combobox3.Text) then begin
          incubator.capacity:=strtoint(edit2.Text);
        end;
        write(tempincubatorfile, incubator);
      end;
      closefile(incubatorfile);
      closefile(tempincubatorfile);
      reset(tempincubatorfile);
      rewrite(incubatorfile);
      while not eof(tempincubatorfile) do begin
        read(tempincubatorfile, incubator);
        write(incubatorfile, incubator);
      end;
      closefile(incubatorfile);
      closefile(tempincubatorfile);
      //done editing file
      button4click(self.ComboBox3);
      panel5.Caption:=combobox3.Text+' edited successfuly';  start:=3;
      exit;
    end;
    if(directoryexists(filepat+'\temp')=false) then createdir(filepat+'\temp');
    //get the number of ggs
    incubatorn:=0;
    if(fileexists(filepat+'\incubator.bin')=true) then begin
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        if(incubatorn<incubator.sn) then incubatorn:=incubator.sn;
      end;
      closefile(incubatorfile);
    end;
    incubatorn:=incubatorn+1;
    //done with egg number
    assignfile(tempincubatorfile, filepat+'\temp\incubator.bin');
    assignfile(incubatorfile, filepat+'\incubator.bin');
    rewrite(tempincubatorfile);
    incubator.sn:=incubatorn;
    incubator.name:=combobox3.Text;
    incubator.capacity:=strtoint(edit2.Text);
    incubator.loaddate:=date;
    incubator.incubating:=false;
    write(tempincubatorfile, incubator);
    if(fileexists(filepat+'\incubator.bin')=true) then begin
      assignfile(incubatorfile, filepat+'\incubator.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
        read(incubatorfile, incubator);
        write(tempincubatorfile, incubator);
      end;
      closefile(incubatorfile);
    end;
    closefile(tempincubatorfile);
    reset(tempincubatorfile);
    rewrite(incubatorfile);
    while not eof(tempincubatorfile) do begin
      read(tempincubatorfile, incubator);
      write(incubatorfile, incubator);
    end;
    closefile(tempincubatorfile);
    closefile(incubatorfile);
    combobox3.Items.Add(combobox3.Text);
    button4click(self.ComboBox3);
    panel5.Caption:=incubator.name +' added successfuly '; start:=3;
 end;
end;

procedure TForm2.ransaction1Click(Sender: TObject);
begin
  panel21.Hide;
  panel19.Visible:=not panel19.Visible;
end;

procedure TForm2.Button8Click(Sender: TObject);
var
ddd, mnn, yyy:word;
number, code:integer;
begin
 if(edit3.Text='') or (edit4.Text='')  then begin
  panel5.Caption:='Enter complete time'; start:=5;
  edit3.SetFocus; exit;
 end;
 val(edit3.Text, number, code);
 if(code<>0) then begin
   panel5.Caption:='Invalid input for Hours'; edit3.SetFocus; start:=3; exit;
 end;
 hh:=number;
 val(edit4.Text, number, code);
 if(code<>0) then begin
   panel5.Caption:='Invalid input for Minutes'; edit4.SetFocus; start:=3; exit;
 end;
 mm:=number;
 decodedate(today, yyy, mnn, ddd);
 dd:=ddd; yy:=yyy;  mn:=mnn;
 command:=3;
 button5click(self.Button5);
end;

procedure TForm2.Button3Click(Sender: TObject);
type
Tincubatorrecord=record
  mm:integer;
  hh:integer;
  day:integer;
  t:real;
  h:real;
end;

function getnext():string;
var
tempstr:string;
pos, i:integer;
begin
  tempstr:=''; i:=1; pos:=1;
  while(information[pos]<>',') do begin
    tempstr:=tempstr+information[pos];
    pos:=pos+1;
    i:=i+1;
  end;
  if(information<>'') then
     information:=copy(information, i+1, (length(information)-i));
  result:=tempstr;
end;
function its(wha:integer):string;
var
  i, tempd:integer;
  temps:string;
  ch:char;
begin
  i:=2; temps:='';
    while(i>0) do begin
      temps:=temps+inttostr(wha mod 10);
      wha:=wha div 10;
      i:=i-1;
    end;
    ch:=temps[1];
    temps[1]:=temps[2];
    temps[2]:=ch;
    result:=temps;
end;
var
  incubatorrecord, incure:tincubatorrecord;
  incubatorfile:file of tincubatorrecord;
  hh, mm, ss, ms:word;
  i:integer;
begin
  panel5.Caption:='';
  if(length(information)<=0) then exit;
  if(information[1]='d') then begin
    memo1.Lines.Add('Jagon: '+information); exit;
  end;
  memo1.Lines.Add('Data: '+information);
  reply:=strtoint(getnext());
  hu:= strtofloat(getnext());
  hd:=strtofloat(getnext());
  tu:=strtofloat(getnext());
  td:=strtofloat(getnext());
  vent:= strtoint(getnext());
  rot:= strtoint(getnext());
  dd:= strtoint(getnext());
  hh:= strtoint(getnext());
  mn:= strtoint(getnext());
  mm:= strtoint(getnext());
  yy:=strtoint(getnext());
  controller:=strtoint(getnext());
  server:=strtoint(getnext());
  command:=strtoint(getnext());
  //memo1.Lines.Add('hh: '+inttostr(hh));
   //memo1.Lines.Add('command: '+inttostr(command));
  if(controller=13) and (server=14) then begin
    case command of
     5: begin
         i:=(hh*2)+ (mm div 30);
         stringgrid2.Cells[1, i+1]:=inttostr(hh)+':'+inttostr(mm);
         stringgrid2.Cells[2, i+1]:=floattostr(td);
         stringgrid2.Cells[3, i+1]:=floattostr(hd);
         incubatorrecord.mm:=mm;
         incubatorrecord.hh:=hh;
         incubatorrecord.day:=dd;
         incubatorrecord.t:=td;
         incubatorrecord.h:=hd;
         assignfile(incubatorfile, filepat+'\incubatorrecord.bin');
         if(fileexists(filepat+'\incubatorrecord.bin')=true) and (incubatorn=1) then begin
            reset(incubatorfile);
            while not eof(incubatorfile) do read(incubatorfile, incure);
            write(incubatorfile, incubatorrecord);
            closefile(incubatorfile);
         end else begin
          rewrite(incubatorfile);
          write(incubatorfile, incubatorrecord);
          closefile(incubatorfile);
         end;
       end;
     6: begin
        label19.Caption:=floattostr(tu)+' Degree';
        label21.Caption:=floattostr(hu)+' %';
        label20.Caption:=floattostr(td)+' Degree';
        label22.Caption:=floattostr(hd)+' %';
        label9.Caption:='TIME: '+its(hh)+':'+its(mm);
        label13.Caption:='DATE: '+its(dd)+'-'+its(mn)+'-'+inttostr(yy);
      end;
   end;
  end;
end;

procedure TForm2.Button5Click(Sender: TObject);
var
data:string;
begin
  controller:=13;
  server:=14;
  reply:=0;
  data:=inttostr(reply)+','+ floattostr(hu)+','+floattostr(hd)+','+floattostr(tu)+','+
  floattostr(td)+','+inttostr(vent)+','+inttostr(rot)+','+inttostr(dd)+','+
  inttostr(hh)+','+inttostr(mn)+','+inttostr(mm)+','+inttostr(yy)+','+
  inttostr(controller)+','+inttostr(server)+','+inttostr(command)+',';
  if(comport1.Connected=true) then begin
   comport1.WriteStr(data);
   memo1.Lines.Add('Sending: '+data);
  end  else  begin
    panel5.Caption:='COMPORT NOT CONNECTED';
  end;
end;

procedure TForm2.Button6Click(Sender: TObject);
begin
  if(connected=true) then begin
    //image8click(self.Image8);
    panel4.Show; panel16.Enabled:=false;
    loading:=true;
    loadpos:=-1;
    button4.Caption:='OK';
  end else begin
   panel5.Caption:='INCUBATOR NOT CONNECTED'; start:=3;
  end;
end;

procedure TForm2.ComboBox3Select(Sender: TObject);
begin
  button4click(combobox3);
  if(comport1.Connected=true) then comport1.WriteStr('7');
  connected:=false;
  if(bevel8.Visible=true) then button4.Caption:='CONNECT';
end;

procedure TForm2.Button7Click(Sender: TObject);
var
i:integer;
begin
   panel5.Caption:='UPLOADING DATA: '+inttostr(loadpos)+'/'+inttostr(stringgrid1.RowCount-1);
    command:=2;
    dd:=strtoint(stringgrid1.Cells[0, loadpos]);
    td:=strtofloat(stringgrid1.Cells[1, loadpos]);
    tu:=strtofloat(stringgrid1.Cells[2, loadpos]);
    hd:=strtofloat(stringgrid1.Cells[3, loadpos]);
    hu:=strtofloat(stringgrid1.Cells[4, loadpos]);
    rot:=strtoint(stringgrid1.Cells[5, loadpos]);
    vent:=strtoint(stringgrid1.Cells[6, loadpos]);
    button5click(self.Button5);
    count:=0;
end;

procedure TForm2.Button11Click(Sender: TObject);
type
Tincubatorrecord=record
  mm:integer;
  hh:integer;
  day:integer;
  t:real;
  h:real;
  end;
var
  incubatorrecord:tincubatorrecord;
  incubatorfile:file of tincubatorrecord;
  i, j, number, code:integer;
begin
val(edit6.Text, number, code);
  if(code=0) and (number<=0) then begin
    panel5.Caption:='Enter a valid incubation day'; start:=4; exit;
  END;
  if(combobox4.ItemIndex=0) then begin
    stringgrid2.RowCount:=0;
    if(fileexists(filepat+'\incubatorrecord.bin')=true) and (incubatorn=1) then begin
      Stringgrid2.RowCount:=49;
      for i:=1 to 48 do begin
         stringgrid2.Cells[0, i]:=inttostr(i);
         stringgrid2.Cells[1, i]:='0';
         stringgrid2.Cells[2, i]:='0';
         stringgrid2.Cells[3, i]:='0';
      end;
      assignfile(incubatorfile, filepat+'\incubatorrecord.bin');
      reset(incubatorfile);
      while not eof(incubatorfile) do begin
      read(incubatorfile, incubatorrecord);
      if(incubatorrecord.day=number) then begin
         i:=(incubatorrecord.hh*2)+ (incubatorrecord.mm div 30);
         stringgrid2.Cells[1, i+1]:=inttostr(incubatorrecord.hh)+':'+inttostr(incubatorrecord.mm);
         stringgrid2.Cells[2, i+1]:=floattostr(incubatorrecord.t);
         stringgrid2.Cells[3, i+1]:=floattostr(incubatorrecord.h);
       end;
      end;
    closefile(incubatorfile);
    if(stringgrid1.RowCount=1)  then begin
      panel5.Caption:='No  record found for this day'; start:=3
    end;
    end else begin
      panel5.Caption:='This incubator has no record'; start:=3;
    end;
  end else begin
    command:=5;
    dd:=number;
    button5click(self.Button5);
  end;
end;
procedure TForm2.Label18Click(Sender: TObject);
begin
  panel21.Hide;
end;

procedure TForm2.Button9Click(Sender: TObject);
begin
  panel21.Show;
end;

procedure TForm2.Button12Click(Sender: TObject);
begin
  if(connected=false) then begin
      panel5.Caption:='INCUBATOR NOT CONNECTED'; start:=3; exit;
  end;
 yy:=combobox5.ItemIndex+1;
 if(combobox5.ItemIndex=1) then begin
   if(fan=true) then begin
     fan:=false;
     vent:=0;
   end else begin
     fan:=true;
     vent:=1;
   end;
 end else if(combobox5.ItemIndex=2) then begin
   if(port=true) then begin
     port:=false;
     vent:=0;
   end else begin
     port:=true;
     vent:=1;
   end;
 end;
 command:=7;
 Button5Click(self.Button5);
 label25.Caption:='31';
end;

procedure TForm2.ComboBox5Select(Sender: TObject);
begin
  if(combobox5.ItemIndex=0) then button12.Caption:='NEXT'
  else button12.Caption:='TOGGLE';
end;     
procedure TForm2.Label24Click(Sender: TObject);
begin
  panel17.Hide;
end;

end.

