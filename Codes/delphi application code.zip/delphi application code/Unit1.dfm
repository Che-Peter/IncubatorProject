object FORM1: TFORM1
  Left = 394
  Top = 210
  BorderStyle = bsDialog
  Caption = 'Login'
  ClientHeight = 309
  ClientWidth = 604
  Color = clBtnText
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = True
  Position = poScreenCenter
  WindowState = wsMaximized
  OnCreate = FormCreate
  OnShow = FormShow
  DesignSize = (
    604
    309)
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 11
    Top = 163
    Width = 184
    Height = 36
    Anchors = []
    Caption = 'PASSWORD'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clAqua
    Font.Height = -31
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    Transparent = True
  end
  object Label1: TLabel
    Left = 82
    Top = 91
    Width = 93
    Height = 36
    Anchors = []
    Caption = 'NAME'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clAqua
    Font.Height = -31
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    Transparent = True
    OnClick = Label1Click
  end
  object Edit1: TEdit
    Left = 237
    Top = 92
    Width = 337
    Height = 37
    Anchors = []
    BorderStyle = bsNone
    Color = clBlue
    Font.Charset = ANSI_CHARSET
    Font.Color = clAqua
    Font.Height = -32
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    OnKeyPress = Edit1KeyPress
  end
  object Edit2: TEdit
    Left = 237
    Top = 162
    Width = 337
    Height = 35
    Anchors = []
    BorderStyle = bsNone
    Color = clBlue
    Font.Charset = ANSI_CHARSET
    Font.Color = clAqua
    Font.Height = -37
    Font.Name = 'Bernard MT Condensed'
    Font.Style = []
    ParentFont = False
    PasswordChar = '*'
    TabOrder = 1
    OnKeyPress = Edit1KeyPress
  end
  object Panel1: TPanel
    Left = 0
    Top = 268
    Width = 604
    Height = 41
    Align = alBottom
    Caption = 'Welcome'
    Color = clBackground
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -23
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
  end
end
