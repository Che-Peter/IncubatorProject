program Project2;

uses
  Forms,
  Unit1 in 'Unit1.pas' {FORM1},
  Unit2 in 'Unit2.pas' {Form2};

{$R *.res}
begin
  Application.Initialize;
  Application.CreateForm(TFORM1, FORM1);
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
